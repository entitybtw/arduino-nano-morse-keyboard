// We're really not using this in our implementation, but it still needs to be defined somewhere

#include <vusb/driver/usbdrv.h>
USB_PUBLIC usbMsgLen_t usbFunctionSetup(uchar data[8]) {return 0;}